import org.omg.CORBA.PUBLIC_MEMBER;

public interface IOperation {
	public String perform(String num1, String num2);
}

 
